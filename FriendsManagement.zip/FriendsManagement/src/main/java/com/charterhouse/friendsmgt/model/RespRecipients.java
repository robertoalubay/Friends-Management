package com.charterhouse.friendsmgt.model;

import java.util.Set;

public class RespRecipients {
    boolean success= true;
    Set<String> recipients;

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success= success;
    }

    public Set<String> getRecipients() {
        return recipients;
    }

    public void setRecipients(Set<String> recipients) {
        this.recipients= recipients;
    }

    @Override
    public String toString() {
        return "Recipients [success=" + success + ", recipients=" + recipients + "]";
    }
    
}
