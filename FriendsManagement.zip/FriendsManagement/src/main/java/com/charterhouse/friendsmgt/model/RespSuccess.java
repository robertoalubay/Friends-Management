package com.charterhouse.friendsmgt.model;


public class RespSuccess {
    boolean success= true;

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success= success;
    }

    @Override
    public String toString() {
        return "PageStatus [success=" + success + "]";
    }
    
}
