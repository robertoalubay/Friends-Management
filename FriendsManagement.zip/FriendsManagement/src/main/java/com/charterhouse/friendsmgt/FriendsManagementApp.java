package com.charterhouse.friendsmgt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = { "com.charterhouse.friendsmgt" })

public class FriendsManagementApp {

	public static void main(String[] args) {
		SpringApplication.run(FriendsManagementApp.class, args);
	}
}