package com.charterhouse.friendsmgt.service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.charterhouse.friendsmgt.model.RespRecipients;
import com.charterhouse.friendsmgt.model.User;

@Service("userService")
@Transactional
public class UserServiceImpl implements UserService {
    private static List<User> users;
    
    public static final Logger logger= LoggerFactory.getLogger(UserServiceImpl.class);

    static {
        users= populateInitialUsers();
    }

    private static List<User> populateInitialUsers() {
        User user= new User();
        List<User> users= new ArrayList<User>();
        Set<String> friends= new HashSet<String>();
        Set<String> subscribers= new HashSet<String>();
        Set<String> blockUpdates= new HashSet<String>();
        
        user.setEmail("susan@yahoo.com");
          
        friends.add("andy@yahoo.com");
        friends.add("john@yahoo.com");
        friends.add("roberto@yahoo.com");
        user.setFriends(friends);
        
        subscribers.add("margie@yahoo.com");
        user.setSubscriber(subscribers);
        
        blockUpdates.add("annie@yahoo.com");
        user.setBlockUpdates(blockUpdates);
        
        users.add(user);
        
        user= new User();
        user.setEmail("mark@yahoo.com");
        friends= new HashSet<String>();
          
        friends.add("roberto@yahoo.com");
        user.setFriends(friends);
        
        users.add(user);
        
        return users;
    }
    
    public List<User> getAllUsers() {
        return users;
    }
    
    public User findByEmail(String email) {
        for (User user : users) {
            if (user.getEmail().equalsIgnoreCase(email)) {
                return user;
            }
        }
        return null;
    }
    
    public User addFriend(User currentUser, Set<String> friendToAddList) {
        Set<String> friends= new HashSet<String>();
        
        if (currentUser != null) {
            if (friendToAddList != null && friendToAddList.size() > 0) {
                
                friends= currentUser.getFriends();
                if (friends == null) {
                    friends= new HashSet<String>();
                }
                
                for (String email:friendToAddList) {
                    
                    if (!email.equalsIgnoreCase(currentUser.getEmail())) {
                        if (!friends.contains(email)) {
                            friends.add(email);
                        }
                    }
                }
                
                currentUser.setFriends(friends);
            }
        }
        
        return currentUser;
        
    }
    
    public User commonFriend(Set<String> friendToCompareList) {
        User userCommonFriends= new User();
        Set<String> commonFriends= new HashSet<String>();
        User currentUser= null;
        Set<String> currentUserFriends= null;
        Set<String> friendSet= new HashSet<String>();
        
        if (friendToCompareList != null && friendToCompareList.size() > 0) {
            if (friendToCompareList.size() > 1) {
                for (String email : friendToCompareList) {
                    currentUser= findByEmail(email);

                    if (currentUser != null) {
                        currentUserFriends= currentUser.getFriends();
                        
                        if (currentUserFriends != null && currentUserFriends.size() > 0) {
                            for (String tmpStr:currentUserFriends) {
                                if (friendSet.contains(tmpStr)) {
                                    commonFriends.add(tmpStr);
                                }
                                    
                                friendSet.add(tmpStr);
                            }
                        }
                    } else {
                        logger.info("User not found:" + email, email);
                    }
                }
            } else {
                logger.info("friendToCompareList only contains 1 record." );
            }
            
        }
        
        userCommonFriends.setFriends(commonFriends);
        return userCommonFriends;
    }
    
    public User subscribe(User user, String target) {
        Set<String> subscriberSet= null;
        
        if (user != null) {
            if (user.getSubscriber() != null) {
                user.getSubscriber().add(target);
            } else {
                subscriberSet= new HashSet<String>();
                subscriberSet.add(target);
                user.setSubscriber(subscriberSet);
            }
        } else {
            logger.info("User not found.");
        }
        
        return user;
    }
    
    public User blockUpdates(User user, String target) {
        Set<String> blockUpdatesSet= null;
        
        if (user != null) {
            if (user.getBlockUpdates() != null) {
                user.getBlockUpdates().add(target);
            } else {
                blockUpdatesSet= new HashSet<String>();
                blockUpdatesSet.add(target);
                user.setBlockUpdates(blockUpdatesSet);
            }
        } else {
            logger.info("User not found.");
        }
        
        return user;
    }
    
    public RespRecipients getSubscribers(String email) {
        User user= null;
        RespRecipients respRecipients= new RespRecipients();
        Set<String> subscriberSet= null;
        Set<String> blockUpdates= null;
        
        Set<String> recipients= new HashSet<String>();
        
        respRecipients.setSuccess(false);
        user= findByEmail(email);
        
        if (user != null) {
            
            subscriberSet= user.getSubscriber();
            blockUpdates= user.getBlockUpdates();
            
            if (subscriberSet != null && subscriberSet.size() > 0) {
                for (String tempStr:subscriberSet) {
                    
                    //Check if inside block updates 
                    if (blockUpdates != null && blockUpdates.size() > 0) {
                        if (blockUpdates.contains(tempStr)) {
                            continue;
                        }
                    }
                    
                    recipients.add(tempStr);
                    
                }
                
            }
            
            respRecipients.setSuccess(true);
            respRecipients.setRecipients(recipients);
        } else {
            respRecipients.setSuccess(false);
            logger.info("User not found.");
        }
        
        return respRecipients;
    }
    
    
}