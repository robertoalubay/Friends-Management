package com.charterhouse.friendsmgt.controller;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.charterhouse.friendsmgt.model.RespSuccess;
import com.charterhouse.friendsmgt.model.RespUser;
import com.charterhouse.friendsmgt.model.SenderText;
import com.charterhouse.friendsmgt.model.RespRecipients;
import com.charterhouse.friendsmgt.model.RequestorTarget;
import com.charterhouse.friendsmgt.model.User;
import com.charterhouse.friendsmgt.service.UserService;
import com.charterhouse.friendsmgt.util.CustomErrorType;

@RestController
@RequestMapping("/fm")
public class FriendsManagmentController {

    public static final Logger logger= LoggerFactory.getLogger(FriendsManagmentController.class);

    @Autowired
    UserService userService;
    
    //Get all user
    @RequestMapping(value= "/user", method= RequestMethod.GET)
    public ResponseEntity<List<User>> getAllUsers() {
        List<User> users= userService.getAllUsers();
        if (users.isEmpty()) {
            return new ResponseEntity(HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<List<User>>(users, HttpStatus.OK);
    }

    // Case #1
    @RequestMapping(value= "/addFriend", method= RequestMethod.POST)
    public ResponseEntity<?> addFriend(@RequestBody User user) {
        User currentUser= null;
        Set<String> friendToAddList= new HashSet<String>();
        
        logger.info("Add Friend", user);
        
        friendToAddList= user.getFriends();
            
        if (friendToAddList != null && friendToAddList.size() > 0) {
            for (String email : friendToAddList) {
                currentUser= userService.findByEmail(email);

                if (currentUser != null) {
                    currentUser= userService.addFriend(currentUser, friendToAddList);
                } else {
                    logger.info("User not found:" + email);
                    return new ResponseEntity(new CustomErrorType("User not found: " + email), HttpStatus.NOT_FOUND);
                }
            }
        }
        
        return new ResponseEntity<RespSuccess>(new RespSuccess(), HttpStatus.OK);
    }

    // Case #2
    @RequestMapping(value= "/friends", method= RequestMethod.GET)
    public ResponseEntity<?> getUser(@RequestBody User user) {
        RespUser respUser=  new RespUser();
        
        logger.info("Get friends: " + user.getEmail());
        
        User currentUser= userService.findByEmail(user.getEmail());
        if (user == null) {
            logger.error("User not found: ", user.getEmail());
            return new ResponseEntity(new CustomErrorType("User not found: " + user.getEmail()), HttpStatus.NOT_FOUND);
        }
        
        respUser.setFriends(currentUser.getFriends());
        respUser.setCount(currentUser.getFriends().size());
        return new ResponseEntity<RespUser>(respUser, HttpStatus.OK);
    }
    
    // Case #3
    @RequestMapping(value= "/commonFriend", method= RequestMethod.POST)
    public ResponseEntity<?> commonFriend(@RequestBody User user) {
        User commonFriends= new User();
        RespUser respUser= new RespUser();
        
        logger.info("commonFriend to look for: " + user.toString());
        
        commonFriends= userService.commonFriend(user.getFriends());
        
        respUser.setFriends(commonFriends.getFriends());
        respUser.setCount(commonFriends.getFriends().size());
        
        return new ResponseEntity<RespUser>(respUser, HttpStatus.OK);
    }
    
    // Case #4
    @RequestMapping(value= "/subscribe", method= RequestMethod.POST)
    public ResponseEntity<?> subscribe(@RequestBody RequestorTarget subscription) {
        User user= null;
        
        logger.info("Subscribe, requestor: " + subscription.getRequestor() + ", target: " + subscription.getTarget());
        
        user= userService.findByEmail(subscription.getRequestor());
        if (user == null) {
            logger.error("User not found: ", subscription.getRequestor());
            return new ResponseEntity(new CustomErrorType("User not found: " + subscription.getRequestor()), HttpStatus.NOT_FOUND);
        }
        
        user= userService.subscribe(user, subscription.getTarget());
        
        //return new ResponseEntity<User>(user, HttpStatus.OK);
        return new ResponseEntity<RespSuccess>(new RespSuccess(), HttpStatus.OK);
    }
    
    // Case #5
    @RequestMapping(value= "/blockUpdates", method= RequestMethod.POST)
    public ResponseEntity<?> blockUpdates(@RequestBody RequestorTarget requestorTarget) {
        User user= null;
        
        logger.info("blockUpdates, requestor: " + requestorTarget.getRequestor() + ", target: " + requestorTarget.getTarget());
        
        user= userService.findByEmail(requestorTarget.getRequestor());
        if (user == null) {
            logger.error("User not found: ", requestorTarget.getRequestor());
            return new ResponseEntity(new CustomErrorType("User not found: " + requestorTarget.getRequestor()), HttpStatus.NOT_FOUND);
        }
        
        user= userService.blockUpdates(user, requestorTarget.getTarget());
        
        return new ResponseEntity<RespSuccess>(new RespSuccess(), HttpStatus.OK);
    }
    
    // Case #6
    @RequestMapping(value= "/subscribers", method= RequestMethod.POST)
    public ResponseEntity<?> getSubscribers(@RequestBody SenderText senderText) {
        RespRecipients respRecipients= new RespRecipients();
                
        logger.info("Get subscribers for sender: " + senderText.getSender());
        
        respRecipients= userService.getSubscribers(senderText.getSender());
        return new ResponseEntity<RespRecipients>(respRecipients, HttpStatus.OK);
    }

}