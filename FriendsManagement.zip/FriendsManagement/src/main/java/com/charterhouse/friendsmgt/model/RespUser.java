package com.charterhouse.friendsmgt.model;

import java.util.Set;

public class RespUser {
    boolean success= true;
	Set<String> friends;
	int count;
	
    public boolean isSuccess() {
        return success;
    }
    public void setSuccess(boolean success) {
        this.success= success;
    }
    public Set<String> getFriends() {
        return friends;
    }
    public void setFriends(Set<String> friends) {
        this.friends= friends;
    }
    public int getCount() {
        return count;
    }
    public void setCount(int count) {
        this.count= count;
    }
    @Override
    public String toString() {
        return "RespUser [success=" + success + ", friends=" + friends + ", count=" + count + "]";
    }
}
