package com.charterhouse.friendsmgt.model;


public class RequestorTarget {
    String requestor;
    String target;
    
    public String getRequestor() {
        return requestor;
    }
    public void setRequestor(String requestor) {
        this.requestor= requestor;
    }
    public String getTarget() {
        return target;
    }
    public void setTarget(String target) {
        this.target= target;
    }
    
    @Override
    public String toString() {
        return "Subscription [requestor=" + requestor + ", target=" + target + "]";
    }
}
