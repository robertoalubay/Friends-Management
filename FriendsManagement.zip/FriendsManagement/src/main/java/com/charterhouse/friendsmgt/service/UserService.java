package com.charterhouse.friendsmgt.service;

import java.util.List;
import java.util.Set;

import com.charterhouse.friendsmgt.model.RespRecipients;
import com.charterhouse.friendsmgt.model.User;

public interface UserService {
    List<User> getAllUsers();
    User findByEmail(String email); 
    User addFriend(User currentUser, Set<String> friendToAddList);
    User commonFriend(Set<String> friendToCompareList);
    User subscribe(User user, String target);
    User blockUpdates(User user, String target);
    RespRecipients getSubscribers(String email);
}