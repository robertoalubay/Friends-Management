package com.charterhouse.friendsmgt.model;

import java.util.Set;

public class User {
    String email;
	Set<String> friends;
	Set<String> subscriber;
	Set<String> blockUpdates;
	
    public Set<String> getFriends() {
        return friends;
    }

    public void setFriends(Set<String> friends) {
        this.friends= friends;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email= email;
    }
    
    public Set<String> getSubscriber() {
        return subscriber;
    }

    public void setSubscriber(Set<String> subscriber) {
        this.subscriber= subscriber;
    }
    
    public Set<String> getBlockUpdates() {
        return blockUpdates;
    }

    public void setBlockUpdates(Set<String> blockUpdates) {
        this.blockUpdates= blockUpdates;
    }

    @Override
    public String toString() {
        return "User [email=" + email + ", friends=" + friends + ", subscriber=" + subscriber + ", blockUpdates=" + blockUpdates + "]";
    }
        
}
