Friends Management Using Java 1.8 Spring Boot Rest

This is for "Friends Management" REST application using Java 1.8 Spring Boot Rest and build under Maven.
Can extract "FriendsManagement.zip"
  - Once the "FriendsManagement.zip" is extracted, can run at the command prompt using "mvn spring-boot:run"
  - Or can run the "FriendsManagement-0.0.1-SNAPSHOT.jar" by typing, "java -jar target\FriendsManagement-0.0.1-SNAPSHOT.jar".
  
How To Test:

Case #1: http://localhost:8080/fm/addFriend
Case #2: http://localhost:8080/fm/friends
Case #3: http://localhost:8080/fm/commonFriend
Case #4: http://localhost:8080/fm/subscribe
Case #5: http://localhost:8080/fm/blockUpdates
Case #6: http://localhost:8080/fm/subscribers
